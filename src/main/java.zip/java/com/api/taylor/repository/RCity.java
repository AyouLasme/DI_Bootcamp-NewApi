package com.api.taylor.repository;

import com.api.taylor.models.TCity;
import org.springframework.data.repository.CrudRepository;

public interface RCity extends CrudRepository<TCity, Long> {
}
